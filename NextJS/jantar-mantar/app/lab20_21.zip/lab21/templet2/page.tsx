export default function Template2() {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "100vh",
        backgroundColor: "#f2f2f2",
      }}
    >
      <div
        style={{
          width: "300px",
          backgroundColor: "white",
          borderRadius: "10px",
          boxShadow: "0 4px 8px gray",
          padding: "20px",
          textAlign: "center",
          color: "black",
        }}
      >
    <h1>Welcome To Templet2</h1>
    </div>
    </div>
  );
}