export default function Template1() {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "100vh",
        backgroundColor: "pink",
      }}
    >
      <div
        style={{
          width: "400px",
          backgroundColor: "white",
          borderRadius: "10px",
          boxShadow: "0 4px 8px gray",
          padding: "20px",
          textAlign: "center",
          justifyContent:"center",
          color: "black",
          height:"500px"
        }}
      >
    
      <h1>Welcome To Templete 1</h1>
    </div>
    </div>
  );
}