import Link from "next/link";

export default function Lab21() {
  return (
    <div
      style={{
        height: "100vh",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        background: "#f4f4f4",
      }}
    >
      <h1>Lab 21 - HTML/CSS Templates</h1>

      <div style={{ display: "flex", gap: "20px", marginTop: "30px" }}>
        <Link href="/lab21/layout">Templates</Link>
        
      </div>
    </div>
  );
}