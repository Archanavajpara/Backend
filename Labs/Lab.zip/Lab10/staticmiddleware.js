const express = require('express');
const app = express();


app.use(express.static(__dirname));

app.listen(3000, () => {
    console.log('Server is running on port on http://localhost:3000');
});